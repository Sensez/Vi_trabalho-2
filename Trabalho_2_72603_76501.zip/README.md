Para executar o trabalho basta apenas abrir o ficheiro "index.html" por um browser, de preferencia o browser Firefox.

O trabalho foi apenas executado no browser Firefox. 
